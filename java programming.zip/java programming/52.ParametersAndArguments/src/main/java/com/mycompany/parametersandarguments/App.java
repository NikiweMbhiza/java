/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parametersandarguments;

/**
 *
 * @author Dell-User
 */
public class App {
     static void myMethod(String fname){
     System.out.println("just got executed");
    }
    public static void main(String[] args) {
        myMethod("liam");
        
        myMethod("jerry");
        
        myMethod("anja");
    }
}
