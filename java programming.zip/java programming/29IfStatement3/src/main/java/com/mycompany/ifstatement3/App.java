/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifstatement3;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int time=20;
        if(time <18){
          System.out.println("morning!");
     
        }else{
            System.out.println("goodevening !");
   
        }
        System.out.println("Hello World!");
    }
}
