/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.narrowingcasting;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        double mydouble=9.78d;
        int myInt=(int)mydouble;
        System.out.println(mydouble);
        System.out.println(myInt);
    }
}
