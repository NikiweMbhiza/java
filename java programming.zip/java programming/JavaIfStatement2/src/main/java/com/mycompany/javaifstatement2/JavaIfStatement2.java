/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaifstatement2;

/**
 *
 * @author Dell-User
 */
public class JavaIfStatement2 {

    public static void main(String[] args) {
        
        int x=20;
        int y=18;
                if(x>y){
                    System.out.println("xis is greater");
               
                }
    }
}
