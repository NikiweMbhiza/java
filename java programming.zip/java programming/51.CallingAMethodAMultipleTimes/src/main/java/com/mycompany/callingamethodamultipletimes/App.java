/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.callingamethodamultipletimes;

/**
 *
 * @author Dell-User
 */
public class App {
    static void myMethod(){
     System.out.println("just got executed");
    }
    public static void main(String[] args) {
        
        myMethod();
        
        myMethod();
        
        myMethod();
    }
}
