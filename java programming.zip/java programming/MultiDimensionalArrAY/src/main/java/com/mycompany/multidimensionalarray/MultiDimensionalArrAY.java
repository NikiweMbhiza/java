/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multidimensionalarray;

/**
 *
 * @author Dell-User
 */
public class MultiDimensionalArrAY {

    public static void main(String[] args) {
        int[][]myNumbers={{1,2,3,4},{5,6,7,8}};
        
        System.out.println(myNumbers[1][2]);
    }
}
