/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.onevaluetomultiplevariables;

/**
 *
 * @author Dell-User
 */
public class OneValueToMultipleVariables {

    public static void main(String[] args) {
        int x,y,z;
        x=y=z=50;
        System.out.println(x+y+z);
    }
}
