/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javamath;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
      int mymin=  Math.min(5,10);
       double myabs= Math.abs(-4.7);
       double sqaureRoot= Math.sqrt(64);
        System.out.println(mymin);
        System.out.println(sqaureRoot);
        System.out.println(myabs);
        
    }
}
