/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.j38.avabreak;

/**
 *
 * @author Dell-User
 */
public class J38AvaBreak {

    public static void main(String[] args) {
        for(int i=0;i<10;i++){
            if(i==4){
                break;
            }
             
        System.out.println(i);
        }
    }
}
