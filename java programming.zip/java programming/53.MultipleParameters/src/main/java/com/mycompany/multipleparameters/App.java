/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multipleparameters;

/**
 *
 * @author Dell-User
 */
public class App {
    static void myMethod(String fname,int age){
     System.out.println("just got executed");
    }

    public static void main(String[] args) {
     myMethod("liam",55);
        
        myMethod("jerry",66);
        
        myMethod("anja",33);
    }
}
