/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.typecasting;

/**
 *
 * @author Dell-User
 */
public class TypeCasting {

    public static void main(String[] args) {
       int myInt=9;
       double  mydouble=myInt;
       System.out.println(myInt);
        System.out.println(mydouble);
    }
}
