/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.defaultkeyword;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int day=4;
        switch(day){
            case 1:
                System.out.println(" to day is monday");
                break;
            case 2:
                System.out.println(" to day is tuesday");
                break;
            default:   
        }
    }
}
