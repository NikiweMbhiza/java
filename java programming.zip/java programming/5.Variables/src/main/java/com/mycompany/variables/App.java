/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.variables;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        //System.out.println("Hello World!");
       //this is the syntax: type variableName=value;
        //String name ="John";
        //System.out.println(name);
        int myNum=5;
        float myFloat=5.99f;
        char myLetter='d';
        boolean mybool=true;
        String text="hello";
        
        System.out.println(myNum);
        System.out.println(myFloat);
        
        
        System.out.println(mybool);
        System.out.println(myLetter);
        System.out.println(text);
        
        
        
        
        
        
        
                
    }
}
