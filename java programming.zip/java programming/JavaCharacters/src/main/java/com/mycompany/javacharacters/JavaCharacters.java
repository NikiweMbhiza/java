/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacharacters;

/**
 *
 * @author Dell-User
 */
public class JavaCharacters {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        char myGrade= 'A';
        System.out.println(myGrade);
    }
}
