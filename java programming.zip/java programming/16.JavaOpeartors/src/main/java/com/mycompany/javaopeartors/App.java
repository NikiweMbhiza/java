/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaopeartors;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int sum1=100+50;
        int sum2 =sum1 +250;
        int sum3= sum2+sum2;
        
        System.out.println(sum3);
    }
}
