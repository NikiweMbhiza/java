/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaif.els;

/**
 *
 * @author Dell-User
 */
public class JavaIfEls {

    public static void main(String[] args) {
        if(20>18){
         System.out.println("20 is greater than 18!");
      
        }
        
    }
}
