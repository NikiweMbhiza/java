/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numbers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        byte mybyte=100;
        System.out.println(mybyte);
        
        float f1=35e3f;
        double d1= 12E4d;
        System.out.println(f1);
        System.out.println( d1);
    }
}
