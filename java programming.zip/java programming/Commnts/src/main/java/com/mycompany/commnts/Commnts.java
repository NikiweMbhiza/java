/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.commnts;

/**
 *
 * @author Dell-User
 */
public class Commnts {

    public static void main(String[] args) {
        
        //this is a comment
        System.out.println("Hello World!");
        System.out.println("Hello World!");//this is a comment
    }
}
