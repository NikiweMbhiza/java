/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.identifiers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        //int minutesPerHour=60;
        int m=60;
        System.out.println(m);
    }
}
