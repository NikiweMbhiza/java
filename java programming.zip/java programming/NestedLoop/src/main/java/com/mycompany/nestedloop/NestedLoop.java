/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nestedloop;

/**
 *
 * @author Dell-User
 */
public class NestedLoop {

    public static void main(String[] args) {
        
        //outer loop
        for(int i=1;i<2;i++){
          System.out.println("outer");   
        }
        for(int j=1;j<2;j++){
          System.out.println("inner");   
        }
       
    }
}
