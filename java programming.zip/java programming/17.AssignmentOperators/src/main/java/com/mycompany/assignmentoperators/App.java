/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignmentoperators;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int x=10;
        x*=5;
        
        System.out.println(x);
    }
}
